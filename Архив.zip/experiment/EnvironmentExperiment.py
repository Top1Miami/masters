from ITMO_FS import UnivariateFilter
from ITMO_FS import pearson_corr
from ITMO_FS import select_k_best
from ITMO_FS import su_measure
from sklearn.linear_model import SGDClassifier
from sklearn.model_selection import cross_val_score

from experiment.Experiment import Experiment


class EnvironmentExperiment(Experiment):
    # su_measure fechner_corr spearman_corr pearson_corr information_gain
    # gini_index chi2_measure relief_measure reliefF_measure laplacian_score anova
    feature_functions = [pearson_corr, su_measure, ]
    feature_selectors = [UnivariateFilter(feature_function, select_k_best(30)) for feature_function in
                         feature_functions]

    def run(self, features, labels, file_name):
        for feature_selector in EnvironmentExperiment.feature_selectors:
            feature_selector.fit_transform(features, labels)
            classifier = SGDClassifier(max_iter=1000, tol=1e-3)
            print(feature_selector)
            print("Selected features", sorted(feature_selector.selected_features_))
            print(cross_val_score(classifier, features[:, feature_selector.selected_features_], labels))
            print("all features")
            classifier = SGDClassifier(max_iter=1000, tol=1e-3)
            print(cross_val_score(classifier, features, labels))
            return cross_val_score(classifier, features, labels)

    @staticmethod
    def difference(l1, l2):
        s1 = set(l1)
        s2 = set(l2)
        print("Number of matches ", len(s1.intersection(l2)))
        print("Number of old not selected", len(s2.difference(s1)))
        print("Not selected from old", s2.difference(s1))
