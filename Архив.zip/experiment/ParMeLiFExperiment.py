import random

import numpy as np

from experiment import Experiment


class ParMeLiFExperiment(Experiment):

    features = [
        [5, 10, 49, 55, 64, 152, 199, 205, 221, 226, 243, 255, 259, 278, 285, 286, 296, 323, 336, 338, 377, 410, 413,
         442, 444, 453, 472, 481, 493, 496],  # 1.csv
        [92, 108, 110, 120, 129, 167, 173, 177, 189, 208, 322, 388, 391, 417, 461, 501, 509, 573, 642, 668, 676, 726,
         753, 757, 766, 803, 836, 879, 933, 938],  # 2.csv
        [385, 413, 427, 428, 454, 455, 456, 457, 458, 459, 482, 483, 484, 485, 486, 487, 510, 511, 512, 513, 514, 515,
         539, 540, 541, 542, 543, 568, 569, 570],  # 3.csv
        [0, 22, 24, 29, 32, 35, 52, 65, 80, 113, 120, 121, 124, 132, 133, 135, 142, 147, 150, 158, 168, 177, 183, 184,
         191, 192, 200, 209, 237, 238],  # 4.csv
        [10, 13, 30, 43, 44, 93, 99, 254, 375, 413, 421, 443, 479, 487, 518, 573, 595, 600, 619, 655, 682, 694, 723,
         741, 748, 754, 761, 809, 841, 878],  # 5.csv
        [2, 7, 9, 26, 63, 77, 82, 87, 145, 176, 181, 195, 208, 468, 594, 595, 606, 621, 658, 659, 738, 746, 958, 978,
         1003, 1035, 1060, 1086, 1168, 1280]  # 6.csv
    ]

    def run(self, features, labels, file_name):
        known_features = ParMeLiFExperiment.features[int(file_name[:-4]) - 1]
        class_zero, class_first, count_zero, count_first = ParMeLiFExperiment.generate_sampling_data(labels)
        other_features = [i for i in range(0, len(features[0])) if i not in known_features]
        number_of_other_features = len(other_features)
        for _ in range(0, 20):
            sample_indices_object = ParMeLiFExperiment.generate_sample(class_zero, class_first, count_zero, count_first)

            train_known_features, test_known_features = ParMeLiFExperiment.split_features(known_features)

            sample_other_features = random.sample(other_features, number_of_other_features)
            train_other_features, test_other_features = ParMeLiFExperiment.split_features(sample_other_features)

            train_joined_features = ParMeLiFExperiment.join_features(train_other_features, train_known_features)
            test_joined_features = ParMeLiFExperiment.join_features(test_other_features, test_known_features)
            train_mapping = ParMeLiFExperiment.generate_mapping(train_joined_features, train_known_features)
            test_mapping = ParMeLiFExperiment.generate_mapping(test_joined_features, test_known_features)

    # rewrite generate_mapping and leading score functions
    #@staticmethod
    #def feature_prec(mapping, known_features):

    @staticmethod
    def generate_mapping(features, known_features):
        mapping = {}
        for i in range(0, len(features)):
            if features[i] in known_features:
                mapping[i] = features[i]
        return mapping

    @staticmethod
    def join_features(l1, l2):
        l3 = l1 + l2
        random.shuffle(l3)
        return l3

    @staticmethod
    def split_features(features, train=20):
        train_features = random.sample(features, train)
        test_features = [i for i in features if i not in train_features]
        return train_features, test_features

    @staticmethod
    def generate_sampling_data(labels, subsample_size=100):
        class_zero = np.where(labels == 0)[0]
        class_first = np.where(labels == 1)[0]
        count_zero = int(float(len(class_zero)) / len(labels) * subsample_size)
        count_first = int(float(len(class_first)) / len(labels) * subsample_size)
        print("Number of objects", len(labels), "Number of zero class objects", len(class_zero),
              "Number of first class objects", len(class_first))
        print("Number of scaled zero class", count_zero, "Number of scaled first class", count_first)
        return class_zero, class_first, count_zero, count_first

    @staticmethod
    def generate_sample(class_zero, class_first, count_zero, count_first):
        zero = np.random.choice(class_zero, count_zero)
        first = np.random.choice(class_first, count_first)
        return [*zero, *first]
