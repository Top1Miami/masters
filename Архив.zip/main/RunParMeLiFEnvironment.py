from experiment import ParMeLiFExperiment
from pipeline import PipeLine

pipeline = PipeLine('../datasets')
experiment = ParMeLiFExperiment()
pipeline.run(experiment)
